package com.baseflow.geolocator.errors;

import android.annotation.SuppressLint;

@SuppressWarnings("serial")
public class PermissionUndefinedException extends Exception {}
